﻿namespace FinalProject {
    
    
    public partial class AppDBDataSet {
    }
}

namespace FinalProject.AppDBDataSetTableAdapters {
    
    
    public partial class UsersTableAdapter {
    }
}
